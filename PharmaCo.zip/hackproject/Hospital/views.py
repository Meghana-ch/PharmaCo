from django.shortcuts import render
from Pharma.models import PharmaEntry 
from Hospital.models import patient
from django.core.mail import send_mail

# Create your views here.
def Hosp_home(request):
    return render(request, 'Hospital/hhome.html')

def hnew(request):
    products = PharmaEntry.objects.all()
    return render(request, 'Hospital/hnew.html', {'products':products})

def hpatients(request):
    listed = patient.objects.all()
    if request.method == 'POST' and 'run_script' in request.POST:

    # import function to run
    # from path_to_script import function_to_run

    # call function
        send_mail('PharmaCo', 'Dear customer, There are some newly released medicines and medical products. Please check with the hospital.',
        'meghana23.chikkam@gmail.com',['sssrihari2000@gmail.com','meghana.chikkam@yahoo.com'],fail_silently=False)

    # return user to required page
        # return HttpResponseRedirect(reverse('Hospital:hpatients')
    return render(request, 'Hospital/hpatients.html', {'listed': listed})

# def sendemail():
#     send_mail('PharmaCo', 'Dear customer, There are some newly released medicines and medical products. Please check with the hospital.',
#         'meghana23.chikkam@gmail.com',['sssrihari2000@gmail.com','meghana.chikkam@yahoo.com'],fail_silently=False)

# if request.method == 'POST' and 'run_script' in request.POST:

#     # import function to run
#     # from path_to_script import function_to_run

#     # call function
#         send_mail('PharmaCo', 'Dear customer, There are some newly released medicines and medical products. Please check with the hospital.',
#         'meghana23.chikkam@gmail.com',['sssrihari2000@gmail.com','meghana.chikkam@yahoo.com'],fail_silently=False)

#     # return user to required page
#     return HttpResponseRedirect(reverse('Hospital:hpatients')