from django.urls import path 
from . import views

urlpatterns = [
    path('Hosp_home/', views.Hosp_home, name = 'Hosp_home'),
    path('hnew/',views.hnew,name='hnew'),
    path('hpatients/',views.hpatients,name='hpatients'),
]