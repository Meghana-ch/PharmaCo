from django.db import connections
from django.db import models

# Create your models here
class patient(models.Model):
    id = models.AutoField(primary_key=True)
    Patient_Name = models.CharField(max_length=1000)
    Email = models.CharField(max_length=500)
    Mobile_Number = models.BigIntegerField()
    Age = models.SmallIntegerField()
    Conditions = models.TextField()
    def __str__(self):
        return self.Patient_Name