from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
# from django_project import helpers
from django.contrib import auth
from django.contrib.messages import constants as messages

# Create your views here.
def home(request):
    return render(request, 'core/home.html')

def service(request):
    return render(request, 'core/service.html')

def about(request):
    return render(request, 'core/about.html')

def register(request):
    return render(request, 'core/register.html')

def error(request):
    return render(request, 'core/error.html')

def afterregister(request):
    return render(request, 'core/afterregister.html')

def enter(request):
    # if request.user.is_authenticated():
    #     return redirect('/services')

    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = auth.authenticate(username=username, password=password)

        if user is not None:
            # correct username and password login the user
            auth.login(request, user)
            if (username == 'Pharma_company'):
                return redirect('phome')
            elif (username == 'Hospital'):
                return redirect('Hosp_home')

        else:
            return redirect('error')
    return render(request, 'core/home.html')