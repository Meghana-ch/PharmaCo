// function productUpdate() {
//     if ($("#productname").val() != null &&
//         $("#productname").val() != '') {
//       // Add product to Table
//       productAddToTable();
//       // Clear form fields
//       formClear();
//       // Focus to product name field
//       $("#productname").focus();
//     }
//   }

//   function formClear() {
//     $("#productname").val("");
//     $("#introdate").val("");
//     $("#url").val("");
//   }

