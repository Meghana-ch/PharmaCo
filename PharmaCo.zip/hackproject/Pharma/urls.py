from django.urls import path
from . import views
from django.conf.urls import include, url
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('phome/', views.phome, name = 'phome'),
    # path('LNP/', views.lnp, name = 'LNP'),
    url(r'^entry/', views.entryview, name = 'entry'),
    path('feedback/', views.fb, name = 'feedback'),
]
if settings.DEBUG:
        urlpatterns += static(settings.MEDIA_URL,
                              document_root=settings.MEDIA_ROOT)