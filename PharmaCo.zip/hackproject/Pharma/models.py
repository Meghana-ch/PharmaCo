from django.db import models

# Create your models here.
class PharmaEntry(models.Model):
    id = models.AutoField(primary_key = True)
    product_name = models.CharField(max_length=100)
    release_date = models.DateField()
    contact_number = models.BigIntegerField()
    product_description = models.TextField()
    def __str__(self):
        return self.product_name

class feedback(models.Model):
    idfeedback = models.AutoField(primary_key= True)
    Product_Name = models.CharField(max_length=1000)
    Condition = models.CharField(max_length=500)
    Rating = models.SmallIntegerField()
    Comments = models.TextField()
    def __str__(self):
        return self.Product_Name