from django.shortcuts import render
from Pharma.forms import entryform
from Pharma.models import PharmaEntry, feedback
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.core.files.storage import FileSystemStorage
from django.conf import settings
from django.contrib import messages
from django.template import RequestContext

# Create your views here.
def phome(request):
    return render(request, 'Pharma/phome.html')

def entryview(request):
    if request.method == 'POST':
        form = entryform(request.POST)
        if form.is_valid():
            product_name = request.POST.get("product_name")
            release_date = request.POST.get("release_date")
            contact_number = request.POST.get("contact_number")
            product_description = request.POST.get("product_description")
            entry_obj = PharmaEntry(product_name = product_name, release_date = release_date, contact_number = contact_number,
             product_description = product_description)
            entry_obj.save()
            messages.success(request, 'Upload Successful!!!')
            return HttpResponseRedirect(reverse('entry'))
    else:
        form = entryform()
    
    return render(request, 'Pharma/LNP.html', {
        'form': form,
    })

def fb(request):
    content = feedback.objects.all()
    return render(request, 'Pharma/feedback.html', {'content':content})