from django import forms

class entryform (forms.Form):
    product_name = forms.CharField(max_length=100)
    release_date = forms.DateField()
    contact_number = forms.NumberInput()
    product_description = forms.Textarea()