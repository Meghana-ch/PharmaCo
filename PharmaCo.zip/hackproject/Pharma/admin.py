from django.contrib import admin
from .models import PharmaEntry, feedback

# Register your models here.
admin.site.register(PharmaEntry)
admin.site.register(feedback)